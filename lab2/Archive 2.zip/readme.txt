py readability.py test2.txt
New Flesch Reading Ease: 71.31
Flesch-Kincade Grade Level: 5.57
Dale-Chall Readability Score: 8.69
Dale-Chall Readability Grade: Grade 11-12
Gunning-Fog Index: 8.41
SMOG Grade: 7.47

py similarity.py cat dog
path length based similarity:   0.200
resnik similarity:              5.657
lin similarity:                 0.744
jc similarity:                  3.902
elesk similarity:               39.000

